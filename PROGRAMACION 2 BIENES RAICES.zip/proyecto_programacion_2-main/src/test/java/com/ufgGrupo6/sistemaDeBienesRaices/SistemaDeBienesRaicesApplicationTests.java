package com.ufgGrupo6.sistemaDeBienesRaices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaDeBienesRaicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
