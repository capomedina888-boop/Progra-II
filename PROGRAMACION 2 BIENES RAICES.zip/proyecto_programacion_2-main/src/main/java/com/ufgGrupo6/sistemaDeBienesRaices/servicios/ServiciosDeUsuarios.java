package com.ufgGrupo6.sistemaDeBienesRaices.servicios;

import org.springframework.stereotype.Service;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.Usuario;
import com.ufgGrupo6.sistemaDeBienesRaices.repositorios.UsuarioRepositorio;
import jakarta.transaction.Transactional;

@Service
public class ServiciosDeUsuarios {
    private final UsuarioRepositorio usuarioRepositorio;

    public ServiciosDeUsuarios(UsuarioRepositorio usuarioRepositorio) {
        this.usuarioRepositorio = usuarioRepositorio;
    }

    public Usuario buscarPorEmail(String email) {
        return usuarioRepositorio.findByEmail(email).orElse(null);
    }

    @Transactional
    public Usuario obtenerOCrearUsuario(String email, String creadoPor) {
        Usuario usuario = buscarPorEmail(email);
        if (usuario == null) {
            if (email == null || email.trim().isEmpty()) {
                throw new RuntimeException("El email no puede estar vacío");
            }
            usuario = new Usuario();
            usuario.setEmail(email);
            usuario.setCreadoPor(creadoPor);
            usuario = usuarioRepositorio.save(usuario);
        }
        return usuario;
    }
}