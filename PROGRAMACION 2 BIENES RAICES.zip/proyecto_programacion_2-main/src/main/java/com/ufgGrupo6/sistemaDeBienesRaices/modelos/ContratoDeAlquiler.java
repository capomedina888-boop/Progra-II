package com.ufgGrupo6.sistemaDeBienesRaices.modelos;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "contratos_de_alquileres")
public class ContratoDeAlquiler {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@OneToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "contrato_id", nullable = false, unique = true)
	private Contrato contrato;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "cuota_id", nullable = false)
	private Cuota cuota;

	@Column(name = "fecha_limite", nullable = false)
	private LocalDateTime fechaLimite;

	@Column(name = "creado_en", nullable = false, updatable = false)
	private LocalDateTime creadoEn;

	@Column(name = "creado_por", nullable = false, updatable = false, length = 255)
	private String creadoPor;

	@Column(name = "actualizado_en", nullable = true)
	private LocalDateTime actualizadoEn;

	@Column(name = "actualizado_por", nullable = true, length = 255)
	private String actualizadoPor;

	public Long getId() { return id; }
	public void setId(Long id) { this.id = id; }

	public Contrato getContrato() { return contrato; }
	public void setContrato(Contrato contrato) {
		if (contrato == null) {
			throw new RuntimeException("El contrato no puede ser nulo");
		}
		this.contrato = contrato;
	}

	public Cuota getCuota() { return cuota; }
	public void setCuota(Cuota cuota) {
		if (cuota == null) {
			throw new RuntimeException("La cuota no puede ser nula");
		}
		this.cuota = cuota;
	}

	public LocalDateTime getFechaLimite() { return fechaLimite; }
	public void setFechaLimite(LocalDateTime fechaLimite) {
		if (fechaLimite == null || fechaLimite.isBefore(LocalDateTime.now().plusDays(1))) {
			throw new RuntimeException("La fecha límite debe ser al menos 1 día en el futuro");
		}
		this.fechaLimite = fechaLimite;
	}

	public LocalDateTime getCreadoEn() { return creadoEn; }
	public void setCreadoEn(LocalDateTime creadoEn) { this.creadoEn = creadoEn; }

	public String getCreadoPor() { return creadoPor; }
	public void setCreadoPor(String creadoPor) {
		if (creadoPor == null || creadoPor.trim().isEmpty()) {
			throw new RuntimeException("El campo creadoPor no puede ser nulo o estar vacío");
		}
		this.creadoPor = creadoPor;
	}

	public LocalDateTime getActualizadoEn() { return actualizadoEn; }
	public void setActualizadoEn(LocalDateTime actualizadoEn) { this.actualizadoEn = actualizadoEn; }

	public String getActualizadoPor() { return actualizadoPor; }
	public void setActualizadoPor(String actualizadoPor) {
		if (actualizadoPor != null && actualizadoPor.trim().isEmpty()) {
			throw new RuntimeException("El campo actualizadoPor no puede estar vacío (puede ser nulo)");
		}
		this.actualizadoPor = actualizadoPor;
	}

	@PrePersist
	private void adquirido() {
		LocalDateTime ahora = LocalDateTime.now();
		if (creadoEn == null) creadoEn = ahora;
		if (actualizadoEn == null) actualizadoEn = ahora;
	}

	@PreUpdate
	private void modificacion() {
		actualizadoEn = LocalDateTime.now();
	}
}