package com.ufgGrupo6.sistemaDeBienesRaices.controladores;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ufgGrupo6.sistemaDeBienesRaices.modelos.Contrato;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.ContratoDeAlquiler;
import com.ufgGrupo6.sistemaDeBienesRaices.servicios.ContratoServices;
import com.ufgGrupo6.sistemaDeBienesRaices.servicios.ServicioDeAlquiler;
import com.ufgGrupo6.sistemaDeBienesRaices.servicios.ServicioDeCompra;
import com.ufgGrupo6.sistemaDeBienesRaices.servicios.ServicioDeVenta;
import com.ufgGrupo6.sistemaDeBienesRaices.servicios.ServiciosDeVisualizacionDeDatos;

@Controller
@RequestMapping("/api/transacciones")
public class ControladorDeContratos {
    private final ServicioDeAlquiler servicioDeAlquiler;
    private final ServicioDeCompra servicioDeCompra;
    private final ServicioDeVenta servicioDeVenta;
    private final ServiciosDeVisualizacionDeDatos visualizacionServicio;
    private final ContratoServices contratoServices;

    public ControladorDeContratos(
            ServicioDeAlquiler servicioDeAlquiler,
            ServicioDeVenta servicioDeVenta,
            ServicioDeCompra servicioDeCompra,
            ServiciosDeVisualizacionDeDatos visualizacionServicio,
            ContratoServices contratoServices) {
        this.servicioDeAlquiler = servicioDeAlquiler;
        this.servicioDeVenta = servicioDeVenta;
        this.servicioDeCompra = servicioDeCompra;
        this.visualizacionServicio = visualizacionServicio;
        this.contratoServices = contratoServices;
    }

    @GetMapping("/form_comprar")
    public String mostrarFormularioComprar(Model model) {
        model.addAttribute("catalogos", visualizacionServicio.inicializacion());
        return "form_comprar";
    }

    @GetMapping("/form_vender")
    public String mostrarFormularioVender() {
        return "form_vender";
    }

    @GetMapping("/form_alquilar")
    public String mostrarFormularioAlquilar(Model model) {
        model.addAttribute("catalogos", visualizacionServicio.inicializacion());
        return "form_alquilar";
    }

    @GetMapping("/exito")
    public String mostrarExito(Model model) {
        model.addAttribute("mensaje", "Operación realizada con éxito.");
        return "exito";
    }

    @PostMapping("/comprar")
    public String comprarBien(String email, BigDecimal valorPropiedad,
            String descripcionPropiedad, String tipoPropiedad, String departamento, Model model) {
        try {
            servicioDeCompra.comprar(email, valorPropiedad, descripcionPropiedad, tipoPropiedad, departamento);
            return "redirect:/api/visualizacion/contratos";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("catalogos", visualizacionServicio.inicializacion());
            return "form_comprar";
        }
    }

    @PostMapping("/vender")
    public String ventaDeBien(String email, Long propiedadId, Model model) {
        try {
            servicioDeVenta.vender(email, propiedadId);
            return "redirect:/api/visualizacion/contratos";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "form_vender";
        }
    }

    @PostMapping("/alquilar")
    public String alquilerDeBien(String email, Long propiedadId, Long cuotaId,
            LocalDateTime fechaInicioDeseada, Model model) {
        try {
            servicioDeAlquiler.alquiler(email, propiedadId, cuotaId, fechaInicioDeseada);
            return "redirect:/api/visualizacion/contratos";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("catalogos", visualizacionServicio.inicializacion());
            return "form_alquilar";
        }
    }

    @GetMapping("/contrato/{id}")
    public String mostrarContrato(@PathVariable Long id, Model model) {
        cargarDetalleContrato(id, model);
        return "detalle_contrato";
    }

    @PostMapping("/contrato/{id}/cancelar")
    public String cancelar(@PathVariable Long id, Model model) {
        try {
            contratoServices.cancelarContrato(id);
            return "redirect:/api/transacciones/contrato/" + id;
        } catch (Exception e) {
            cargarDetalleContrato(id, model);
            model.addAttribute("error", e.getMessage());
            return "detalle_contrato";
        }
    }

    private void cargarDetalleContrato(Long id, Model model) {
        Contrato contrato = contratoServices.buscarPorId(id);
        ContratoDeAlquiler alquiler = contratoServices.buscarAlquilerPorContratoId(id);
        model.addAttribute("contrato", contrato);
        model.addAttribute("alquiler", alquiler);
    }
}
