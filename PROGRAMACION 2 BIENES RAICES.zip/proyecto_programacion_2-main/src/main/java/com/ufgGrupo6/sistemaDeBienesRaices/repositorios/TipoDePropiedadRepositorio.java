package com.ufgGrupo6.sistemaDeBienesRaices.repositorios;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.TipoDePropiedad;

public interface TipoDePropiedadRepositorio extends JpaRepository<TipoDePropiedad, Long> {
    Optional<TipoDePropiedad> findByTipo(String tipo);

}