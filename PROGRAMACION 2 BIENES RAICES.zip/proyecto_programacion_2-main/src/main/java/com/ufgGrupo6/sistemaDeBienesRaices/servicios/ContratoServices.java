package com.ufgGrupo6.sistemaDeBienesRaices.servicios;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ufgGrupo6.sistemaDeBienesRaices.modelos.Contrato;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.ContratoDeAlquiler;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.EstadoDeContrato;
import com.ufgGrupo6.sistemaDeBienesRaices.repositorios.ContratoDeAlquilerRepositorio;
import com.ufgGrupo6.sistemaDeBienesRaices.repositorios.ContratoRepositorio;
import com.ufgGrupo6.sistemaDeBienesRaices.repositorios.EstadoDeContratoRepositorio;

@Service
public class ContratoServices {

    private final ContratoRepositorio contratoRepositorio;
    private final ContratoDeAlquilerRepositorio alquilerRepositorio;
    private final EstadoDeContratoRepositorio estadoRepositorio;

    public ContratoServices(
            ContratoRepositorio contratoRepositorio,
            ContratoDeAlquilerRepositorio alquilerRepositorio,
            EstadoDeContratoRepositorio estadoRepositorio) {
        this.contratoRepositorio = contratoRepositorio;
        this.alquilerRepositorio = alquilerRepositorio;
        this.estadoRepositorio = estadoRepositorio;
    }

    @Transactional(readOnly = true)
    public Contrato buscarPorId(Long id) {
        return contratoRepositorio.findById(id)
                .orElseThrow(() -> new RuntimeException("No existe el contrato con ID " + id));
    }

    @Transactional(readOnly = true)
    public ContratoDeAlquiler buscarAlquilerPorContratoId(Long contratoId) {
        return alquilerRepositorio.findByContratoId(contratoId).orElse(null);
    }

    @Transactional
    public void cancelarContrato(Long id) {
        Contrato contrato = contratoRepositorio.findById(id)
                .orElseThrow(() -> new RuntimeException("No existe el contrato con ID " + id));

        boolean esAlquiler = contrato.getTipoDeContrato().getTipo().equalsIgnoreCase("ALQUILER");
        boolean estaEnProceso = contrato.getEstadoDeContrato().getEstado().equalsIgnoreCase("EN PROCESO");

        if (!esAlquiler || !estaEnProceso) {
            throw new RuntimeException("Solo se pueden cancelar contratos de alquiler en estado EN PROCESO.");
        }

        EstadoDeContrato cancelado = estadoRepositorio.findByEstado("CANCELADO")
                .orElseThrow(() -> new RuntimeException("El estado CANCELADO no existe en la base de datos."));

        contrato.setEstadoDeContrato(cancelado);
        contratoRepositorio.save(contrato);
    }
}
