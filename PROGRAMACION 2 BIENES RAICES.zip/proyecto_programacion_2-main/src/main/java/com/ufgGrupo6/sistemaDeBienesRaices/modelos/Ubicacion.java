package com.ufgGrupo6.sistemaDeBienesRaices.modelos;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "ubicaciones")
public class Ubicacion {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "departamento", nullable = false, unique = true, length = 255)
	private String departamento;

	@Column(name = "zona", nullable = false, length = 255)
	private String zona;

	@Column(name = "creado_en", nullable = false, updatable = false)
	private LocalDateTime creadoEn;

	@Column(name = "creado_por", nullable = false, updatable = false, length = 255)
	private String creadoPor;

	@Column(name = "actualizado_en", nullable = true)
	private LocalDateTime actualizadoEn;

	@Column(name = "actualizado_por", nullable = true, length = 255)
	private String actualizadoPor;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		if (departamento == null || departamento.trim().isEmpty()) {
			throw new RuntimeException("El departamento no puede ser nulo o estar vacío");
		}
		this.departamento = departamento;
	}

	public String getZona() {
		return zona;
	}

	public void setZona(String zona) {
		if (zona == null || zona.trim().isEmpty()) {
			throw new RuntimeException("La zona no puede ser nula o estar vacía");
		}
		this.zona = zona;
	}

	public LocalDateTime getCreadoEn() {
		return creadoEn;
	}

	public void setCreadoEn(LocalDateTime creadoEn) {
		this.creadoEn = creadoEn;
	}

	public String getCreadoPor() {
		return creadoPor;
	}

	public void setCreadoPor(String creadoPor) {
		if (creadoPor == null || creadoPor.trim().isEmpty()) {
			throw new RuntimeException("El campo creadoPor no puede ser nulo o estar vacío");
		}
		this.creadoPor = creadoPor;
	}

	public LocalDateTime getActualizadoEn() {
		return actualizadoEn;
	}

	public void setActualizadoEn(LocalDateTime actualizadoEn) {
		this.actualizadoEn = actualizadoEn;
	}

	public String getActualizadoPor() {
		return actualizadoPor;
	}

	public void setActualizadoPor(String actualizadoPor) {
		if (actualizadoPor != null && actualizadoPor.trim().isEmpty()) {
			throw new RuntimeException("El campo actualizadoPor no puede estar vacío (puede ser nulo)");
		}
		this.actualizadoPor = actualizadoPor;
	}

	@PrePersist
	private void adquirido() {
		LocalDateTime ahora = LocalDateTime.now();
		if (creadoEn == null) creadoEn = ahora;
		if (actualizadoEn == null) actualizadoEn = ahora;
	}

	@PreUpdate
	private void modificacion() {
		actualizadoEn = LocalDateTime.now();
	}
}