package com.ufgGrupo6.sistemaDeBienesRaices.modelos;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "usuarios")
public class Usuario {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "email", nullable = false, unique = true, length = 255)
	private String email;

	@OneToMany(mappedBy = "usuario")
	private List<Propiedad> propiedades = new ArrayList<>();

	@OneToMany(mappedBy = "usuario")
	private List<Contrato> contratos = new ArrayList<>();

	@Column(name = "creado_en", nullable = false, updatable = false)
	private LocalDateTime creadoEn;

	@Column(name = "creado_por", nullable = false, updatable = false, length = 255)
	private String creadoPor;

	@Column(name = "actualizado_en", nullable = true)
	private LocalDateTime actualizadoEn;

	@Column(name = "actualizado_por", nullable = true, length = 255)
	private String actualizadoPor;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		if (email == null || email.trim().isEmpty()) {
			throw new RuntimeException("El email no puede ser nulo o estar vacío");
		}
		this.email = email;
	}

	public List<Propiedad> getPropiedades() {
		return propiedades;
	}

	public void setPropiedades(List<Propiedad> propiedades) {
		this.propiedades = propiedades;
	}

	public List<Contrato> getContratos() {
		return contratos;
	}

	public void setContratos(List<Contrato> contratos) {
		this.contratos = contratos;
	}

	public void agregarContrato(Contrato contrato) {
		if (contrato == null) {
			throw new RuntimeException("El contrato no puede ser nulo");
		}
		if (this.contratos.contains(contrato)) {
			throw new RuntimeException("El contrato ya está asociado a este usuario");
		}
		this.contratos.add(contrato);
		contrato.setUsuario(this);
	}

	public void agregarPropiedad(Propiedad propiedad) {
		if (propiedad == null) {
			throw new RuntimeException("La propiedad no puede ser nula");
		}
		if (this.propiedades.contains(propiedad)) {
			throw new RuntimeException("La propiedad ya está asociada a este usuario");
		}
		this.propiedades.add(propiedad);
		propiedad.setUsuario(this);
	}

	public void eliminarPropiedad(Propiedad propiedad) {
		if (propiedad == null) {
			throw new RuntimeException("La propiedad no puede ser nula");
		}
		if (!this.propiedades.contains(propiedad)) {
			throw new RuntimeException("La propiedad no pertenece a este usuario, no se puede eliminar");
		}
		this.propiedades.remove(propiedad);
		propiedad.setUsuario(null);
	}

	public LocalDateTime getCreadoEn() {
		return creadoEn;
	}

	public void setCreadoEn(LocalDateTime creadoEn) {
		this.creadoEn = creadoEn;
	}

	public String getCreadoPor() {
		return creadoPor;
	}

	public void setCreadoPor(String creadoPor) {
		if (creadoPor == null || creadoPor.trim().isEmpty()) {
			throw new RuntimeException("El campo creadoPor no puede ser nulo o estar vacío");
		}
		this.creadoPor = creadoPor;
	}

	public LocalDateTime getActualizadoEn() {
		return actualizadoEn;
	}

	public void setActualizadoEn(LocalDateTime actualizadoEn) {
		this.actualizadoEn = actualizadoEn;
	}

	public String getActualizadoPor() {
		return actualizadoPor;
	}

	public void setActualizadoPor(String actualizadoPor) {
		if (actualizadoPor != null && actualizadoPor.trim().isEmpty()) {
			throw new RuntimeException("El campo actualizadoPor no puede estar vacío (puede ser nulo)");
		}
		this.actualizadoPor = actualizadoPor;
	}

	@PrePersist
	private void adquirido() {
		LocalDateTime ahora = LocalDateTime.now();
		if (creadoEn == null) creadoEn = ahora;
		if (actualizadoEn == null) actualizadoEn = ahora;
	}

	@PreUpdate
	private void modificacion() {
		actualizadoEn = LocalDateTime.now();
	}
}