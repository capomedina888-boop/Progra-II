package com.ufgGrupo6.sistemaDeBienesRaices.repositorios;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.TipoDeContrato;

public interface TipoDeContratoRepositorio extends JpaRepository<TipoDeContrato, Long> {
    Optional<TipoDeContrato> findByTipo(String tipo);
}