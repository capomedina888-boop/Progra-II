package com.ufgGrupo6.sistemaDeBienesRaices.repositorios;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.Ubicacion;

public interface UbicacionRepositorio extends JpaRepository<Ubicacion, Long> {
    Optional<Ubicacion> findByDepartamento(String departamento);

}