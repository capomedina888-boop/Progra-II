package com.ufgGrupo6.sistemaDeBienesRaices.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ufgGrupo6.sistemaDeBienesRaices.servicios.ServiciosDeVisualizacionDeDatos;

@Controller
@RequestMapping("/api/visualizacion")
public class ControladorDeVisualizacionDeDatos {
    private final ServiciosDeVisualizacionDeDatos visualizacionServicio;

    public ControladorDeVisualizacionDeDatos(ServiciosDeVisualizacionDeDatos visualizacionServicio) {
        this.visualizacionServicio = visualizacionServicio;
    }

    @GetMapping("/catalogos")
    public String mostrarCatalogos(Model model) {
        model.addAttribute("catalogos", visualizacionServicio.inicializacion());
        return "lista_catalogos";
    }

    @GetMapping("/usuarios")
    public String mostrarUsuarios(Model model) {
        model.addAttribute("usuarios", visualizacionServicio.listarUsuarios());
        return "lista_usuarios";
    }

    @GetMapping("/propiedades")
    public String mostrarPropiedades(Model model) {
        model.addAttribute("propiedades", visualizacionServicio.listarPropiedades());
        return "lista_propiedades";
    }

    @GetMapping("/contratos")
    public String mostrarContratos(Model model) {
        model.addAttribute("contratos", visualizacionServicio.listarContratos());
        return "lista_contratos";
    }

    @PostMapping("/catalogos/eliminar/{catalogo}/{id}")
    public String eliminarCatalogo(
            @PathVariable String catalogo,
            @PathVariable Long id,
            RedirectAttributes redirectAttributes) {
        try {
            visualizacionServicio.eliminarDeCatalogo(catalogo, id);
            redirectAttributes.addFlashAttribute("mensaje", "Registro eliminado correctamente.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "No se pudo eliminar: " + e.getMessage());
        }
        return "redirect:/api/visualizacion/catalogos";
    }
}