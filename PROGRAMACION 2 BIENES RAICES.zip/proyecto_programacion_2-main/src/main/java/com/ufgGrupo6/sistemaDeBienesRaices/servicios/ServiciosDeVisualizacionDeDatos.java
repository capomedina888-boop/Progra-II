package com.ufgGrupo6.sistemaDeBienesRaices.servicios;

import org.springframework.stereotype.Service;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.*;
import com.ufgGrupo6.sistemaDeBienesRaices.repositorios.*;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ServiciosDeVisualizacionDeDatos {

    private final CuotaRepositorio cuotaRepositorio;
    private final EstadoDeContratoRepositorio estadoDeContratoRepositorio;
    private final EstadoDePropiedadRepositorio estadoDePropiedadRepositorio;
    private final TipoDeContratoRepositorio tipoDeContratoRepositorio;
    private final TipoDePropiedadRepositorio tipoDePropiedadRepositorio;
    private final UbicacionRepositorio ubicacionRepositorio;
    private final UsuarioRepositorio usuarioRepositorio;
    private final PropiedadRepositorio propiedadRepositorio;
    private final ContratoRepositorio contratoRepositorio;

    private final String adminEmail = "admin@sv.admin.email.com";

    public ServiciosDeVisualizacionDeDatos(
        CuotaRepositorio cuotaRepositorio,
        EstadoDeContratoRepositorio estadoDeContratoRepositorio,
        EstadoDePropiedadRepositorio estadoDePropiedadRepositorio,
        TipoDeContratoRepositorio tipoDeContratoRepositorio,
        TipoDePropiedadRepositorio tipoDePropiedadRepositorio,
        UbicacionRepositorio ubicacionRepositorio,
        UsuarioRepositorio usuarioRepositorio,
        PropiedadRepositorio propiedadRepositorio,
        ContratoRepositorio contratoRepositorio
    ) {
        this.cuotaRepositorio = cuotaRepositorio;
        this.estadoDeContratoRepositorio = estadoDeContratoRepositorio;
        this.estadoDePropiedadRepositorio = estadoDePropiedadRepositorio;
        this.tipoDeContratoRepositorio = tipoDeContratoRepositorio;
        this.tipoDePropiedadRepositorio = tipoDePropiedadRepositorio;
        this.ubicacionRepositorio = ubicacionRepositorio;
        this.usuarioRepositorio = usuarioRepositorio;
        this.propiedadRepositorio = propiedadRepositorio;
        this.contratoRepositorio = contratoRepositorio;
    }

    public Map<String, List<?>> inicializacion() {
        meterAdmin();

        Map<String, List<?>> catalogos = new HashMap<>();
        catalogos.put("cuotas", meterCuotas());
        catalogos.put("estadosContrato", meterEstadosContrato());
        catalogos.put("estadosPropiedad", meterEstadosPropiedad());
        catalogos.put("tiposContrato", meterTiposContrato());
        catalogos.put("tiposPropiedad", meterTiposPropiedad());
        catalogos.put("ubicaciones", meterUbicaciones());
        return catalogos;
    }

    public List<Usuario> listarUsuarios() {
        return usuarioRepositorio.findAll();
    }

    public List<Propiedad> listarPropiedades() {
        return propiedadRepositorio.findAll();
    }

    public List<Contrato> listarContratos() {
        return contratoRepositorio.findAll();
    }

    public void eliminarDeCatalogo(String catalogo, Long id) {
        switch (catalogo) {
            case "cuotas":
                cuotaRepositorio.deleteById(id);
                break;
            case "estadosContrato":
                estadoDeContratoRepositorio.deleteById(id);
                break;
            case "estadosPropiedad":
                estadoDePropiedadRepositorio.deleteById(id);
                break;
            case "tiposContrato":
                tipoDeContratoRepositorio.deleteById(id);
                break;
            case "tiposPropiedad":
                tipoDePropiedadRepositorio.deleteById(id);
                break;
            case "ubicaciones":
                ubicacionRepositorio.deleteById(id);
                break;
            default:
                throw new RuntimeException("Catálogo no reconocido: " + catalogo);
        }
    }

    private void meterAdmin() {
        if (usuarioRepositorio.findByEmail(adminEmail).isEmpty()) {
            Usuario admin = new Usuario();
            admin.setEmail(adminEmail);
            admin.setCreadoPor(adminEmail);
            admin.setActualizadoPor(adminEmail);
            usuarioRepositorio.save(admin);
        }
    }

    private List<Cuota> meterCuotas() {
        if (cuotaRepositorio.count() == 0) {
            Cuota c1 = new Cuota();
            c1.setPeriodo("1 SEMANA");
            c1.setInteres(new BigDecimal("5.00"));
            c1.setCreadoPor(adminEmail);
            c1.setActualizadoPor(adminEmail);
            cuotaRepositorio.save(c1);

            Cuota c2 = new Cuota();
            c2.setPeriodo("1 MES");
            c2.setInteres(new BigDecimal("10.00"));
            c2.setCreadoPor(adminEmail);
            c2.setActualizadoPor(adminEmail);
            cuotaRepositorio.save(c2);
        }
        return cuotaRepositorio.findAll();
    }

    private List<EstadoDeContrato> meterEstadosContrato() {
        String[] estados = {"ACTIVO", "COMPLETADO", "EN PROCESO", "CANCELADO"};
        for (String e : estados) {
            if (estadoDeContratoRepositorio.findByEstado(e).isEmpty()) {
                EstadoDeContrato ec = new EstadoDeContrato();
                ec.setEstado(e);
                ec.setCreadoPor(adminEmail);
                ec.setActualizadoPor(adminEmail);
                estadoDeContratoRepositorio.save(ec);
            }
        }
        return estadoDeContratoRepositorio.findAll();
    }

    private List<EstadoDePropiedad> meterEstadosPropiedad() {
        String[] estados = {"VENDIDA", "ALQUILADA", "DISPONIBLE", "NO_DISPONIBLE"};
        for (String e : estados) {
            if (estadoDePropiedadRepositorio.findByEstado(e).isEmpty()) {
                EstadoDePropiedad ep = new EstadoDePropiedad();
                ep.setEstado(e);
                ep.setCreadoPor(adminEmail);
                ep.setActualizadoPor(adminEmail);
                estadoDePropiedadRepositorio.save(ep);
            }
        }
        return estadoDePropiedadRepositorio.findAll();
    }

    private List<TipoDeContrato> meterTiposContrato() {
        String[] tipos = {"VENTA", "COMPRA", "ALQUILER"};
        for (String t : tipos) {
            if (tipoDeContratoRepositorio.findByTipo(t).isEmpty()) {
                TipoDeContrato tc = new TipoDeContrato();
                tc.setTipo(t);
                tc.setCreadoPor(adminEmail);
                tc.setActualizadoPor(adminEmail);
                tipoDeContratoRepositorio.save(tc);
            }
        }
        return tipoDeContratoRepositorio.findAll();
    }

    private List<TipoDePropiedad> meterTiposPropiedad() {
        String[] tipos = {"CASA", "TERRENO", "DEPARTAMENTO", "EDIFICIO"};
        for (String t : tipos) {
            if (tipoDePropiedadRepositorio.findByTipo(t).isEmpty()) {
                TipoDePropiedad tp = new TipoDePropiedad();
                tp.setTipo(t);
                tp.setCreadoPor(adminEmail);
                tp.setActualizadoPor(adminEmail);
                tipoDePropiedadRepositorio.save(tp);
            }
        }
        return tipoDePropiedadRepositorio.findAll();
    }

    private List<Ubicacion> meterUbicaciones() {
        String[][] datos = {
            {"Ahuachapán", "OCCIDENTAL"}, {"Santa Ana", "OCCIDENTAL"}, {"Sonsonate", "OCCIDENTAL"},
            {"Chalatenango", "CENTRAL"}, {"Cuscatlán", "CENTRAL"}, {"La Libertad", "CENTRAL"},
            {"San Salvador", "CENTRAL"}, {"San Vicente", "CENTRAL"}, {"Cabañas", "CENTRAL"},
            {"La Paz", "CENTRAL"}, {"Usulután", "ORIENTAL"}, {"San Miguel", "ORIENTAL"},
            {"Morazán", "ORIENTAL"}, {"La Unión", "ORIENTAL"}
        };

        for (String[] u : datos) {
            if (ubicacionRepositorio.findByDepartamento(u[0]).isEmpty()) {
                Ubicacion ub = new Ubicacion();
                ub.setDepartamento(u[0]);
                ub.setZona(u[1]);
                ub.setCreadoPor(adminEmail);
                ub.setActualizadoPor(adminEmail);
                ubicacionRepositorio.save(ub);
            }
        }
        return ubicacionRepositorio.findAll();
    }
}