package com.ufgGrupo6.sistemaDeBienesRaices.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.Propiedad;

public interface PropiedadRepositorio extends JpaRepository<Propiedad, Long> {
}