package com.ufgGrupo6.sistemaDeBienesRaices.modelos;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "cuotas")
public class Cuota {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "periodo", nullable = false, unique = true, length = 255)
	private String periodo;

	@Column(name = "interes", precision = 10, scale = 2)
	private BigDecimal interes;

	@Column(name = "creado_en", nullable = false, updatable = false)
	private LocalDateTime creadoEn;

	@Column(name = "creado_por", nullable = false, updatable = false, length = 255)
	private String creadoPor;

	@Column(name = "actualizado_en", nullable = true)
	private LocalDateTime actualizadoEn;

	@Column(name = "actualizado_por", nullable = true, length = 255)
	private String actualizadoPor;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		if (periodo == null || periodo.trim().isEmpty()) {
			throw new RuntimeException("El periodo no puede ser nulo o estar vacío");
		}
		this.periodo = periodo;
	}

	public BigDecimal getInteres() {
		return interes;
	}

	public void setInteres(BigDecimal interes) {
		if (interes == null || interes.compareTo(BigDecimal.ZERO) < 0) {
			throw new RuntimeException("El interés no puede ser nulo ni menor a 0");
		}
		this.interes = interes;
	}

	public LocalDateTime getCreadoEn() {
		return creadoEn;
	}

	public void setCreadoEn(LocalDateTime creadoEn) {
		this.creadoEn = creadoEn;
	}

	public String getCreadoPor() {
		return creadoPor;
	}

	public void setCreadoPor(String creadoPor) {
		if (creadoPor == null || creadoPor.trim().isEmpty()) {
			throw new RuntimeException("El campo creadoPor no puede ser nulo o estar vacío");
		}
		this.creadoPor = creadoPor;
	}

	public LocalDateTime getActualizadoEn() {
		return actualizadoEn;
	}

	public void setActualizadoEn(LocalDateTime actualizadoEn) {
		this.actualizadoEn = actualizadoEn;
	}

	public String getActualizadoPor() {
		return actualizadoPor;
	}

	public void setActualizadoPor(String actualizadoPor) {
		if (actualizadoPor != null && actualizadoPor.trim().isEmpty()) {
			throw new RuntimeException("El campo actualizadoPor no puede estar vacío (puede ser nulo)");
		}
		this.actualizadoPor = actualizadoPor;
	}

	@PrePersist
	private void adquirido() {
		LocalDateTime ahora = LocalDateTime.now();
		if (creadoEn == null) creadoEn = ahora;
		if (actualizadoEn == null) actualizadoEn = ahora;
	}

	@PreUpdate
	private void modificacion() {
		actualizadoEn = LocalDateTime.now();
	}
}