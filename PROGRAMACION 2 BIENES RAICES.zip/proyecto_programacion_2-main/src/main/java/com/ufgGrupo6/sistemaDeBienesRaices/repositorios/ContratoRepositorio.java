package com.ufgGrupo6.sistemaDeBienesRaices.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.Contrato;

public interface ContratoRepositorio extends JpaRepository<Contrato, Long> {
}