package com.ufgGrupo6.sistemaDeBienesRaices.modelos;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "propiedades")
public class Propiedad {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "usuario_id", nullable = false)
	private Usuario usuario;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "tipo_de_propiedad_id", nullable = false)
	private TipoDePropiedad tipoDePropiedad;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "ubicacion_id", nullable = false)
	private Ubicacion ubicacion;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "estado_de_propiedad_id", nullable = false)
	private EstadoDePropiedad estadoDePropiedad;

	@Column(name = "valor", nullable = false, precision = 12, scale = 2)
	private BigDecimal valor;

	@Column(name = "descripcion", length = 1500)
	private String descripcion;

	@Column(name = "creado_en", nullable = false, updatable = false)
	private LocalDateTime creadoEn;

	@Column(name = "creado_por", nullable = false, updatable = false, length = 255)
	private String creadoPor;

	@Column(name = "actualizado_en", nullable = true)
	private LocalDateTime actualizadoEn;

	@Column(name = "actualizado_por", nullable = true, length = 255)
	private String actualizadoPor;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		if (usuario == null) {
			throw new RuntimeException("El usuario no puede ser nulo");
		}
		this.usuario = usuario;
	}

	public TipoDePropiedad getTipoDePropiedad() {
		return tipoDePropiedad;
	}

	public void setTipoDePropiedad(TipoDePropiedad tipoDePropiedad) {
		if (tipoDePropiedad == null) {
			throw new RuntimeException("El tipo de propiedad no puede ser nulo");
		}
		this.tipoDePropiedad = tipoDePropiedad;
	}

	public Ubicacion getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(Ubicacion ubicacion) {
		if (ubicacion == null) {
			throw new RuntimeException("La ubicación no puede ser nula");
		}
		this.ubicacion = ubicacion;
	}

	public EstadoDePropiedad getEstadoDePropiedad() {
		return estadoDePropiedad;
	}

	public void setEstadoDePropiedad(EstadoDePropiedad estadoDePropiedad) {
		if (estadoDePropiedad == null) {
			throw new RuntimeException("El estado de propiedad no puede ser nulo");
		}
		this.estadoDePropiedad = estadoDePropiedad;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		if (valor == null || valor.compareTo(BigDecimal.ZERO) < 0) {
			throw new RuntimeException("El valor no puede ser nulo ni menor a 0");
		}
		this.valor = valor;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public LocalDateTime getCreadoEn() {
		return creadoEn;
	}

	public void setCreadoEn(LocalDateTime creadoEn) {
		this.creadoEn = creadoEn;
	}

	public String getCreadoPor() {
		return creadoPor;
	}

	public void setCreadoPor(String creadoPor) {
		if (creadoPor == null || creadoPor.trim().isEmpty()) {
			throw new RuntimeException("El campo creadoPor no puede ser nulo o estar vacío");
		}
		this.creadoPor = creadoPor;
	}

	public LocalDateTime getActualizadoEn() {
		return actualizadoEn;
	}

	public void setActualizadoEn(LocalDateTime actualizadoEn) {
		this.actualizadoEn = actualizadoEn;
	}

	public String getActualizadoPor() {
		return actualizadoPor;
	}

	public void setActualizadoPor(String actualizadoPor) {
		if (actualizadoPor != null && actualizadoPor.trim().isEmpty()) {
			throw new RuntimeException("El campo actualizadoPor no puede estar vacío (puede ser nulo)");
		}
		this.actualizadoPor = actualizadoPor;
	}

	@PrePersist
	private void adquirido() {
		LocalDateTime ahora = LocalDateTime.now();
		if (creadoEn == null) creadoEn = ahora;
		if (actualizadoEn == null) actualizadoEn = ahora;
	}

	@PreUpdate
	private void modificacion() {
		actualizadoEn = LocalDateTime.now();
	}
}