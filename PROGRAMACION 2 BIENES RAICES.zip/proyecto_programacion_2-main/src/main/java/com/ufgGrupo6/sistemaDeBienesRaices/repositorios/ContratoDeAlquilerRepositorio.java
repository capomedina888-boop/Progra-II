package com.ufgGrupo6.sistemaDeBienesRaices.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.ContratoDeAlquiler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ContratoDeAlquilerRepositorio extends JpaRepository<ContratoDeAlquiler, Long> {

    @Query("SELECT ca FROM ContratoDeAlquiler ca JOIN FETCH ca.cuota WHERE ca.contrato.id = :contratoId")
    Optional<ContratoDeAlquiler> findByContratoId(@Param("contratoId") Long contratoId);

    @Query("SELECT ca FROM ContratoDeAlquiler ca JOIN ca.contrato c JOIN c.propiedad p WHERE p.id = :propiedadId ORDER BY ca.fechaLimite DESC")
    List<ContratoDeAlquiler> findUltimoAlquilerPorPropiedad(@Param("propiedadId") Long propiedadId);

    @Query("SELECT ca FROM ContratoDeAlquiler ca JOIN ca.contrato c WHERE c.estadoDeContrato.estado = 'EN PROCESO' AND ca.fechaLimite < :ahora")
    List<ContratoDeAlquiler> findAlquileresVencidos(@Param("ahora") LocalDateTime ahora);
}