package com.ufgGrupo6.sistemaDeBienesRaices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaDeBienesRaicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaDeBienesRaicesApplication.class, args);
	}

}
