package com.ufgGrupo6.sistemaDeBienesRaices.modelos;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "contratos")
public class Contrato {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "usuario_id", nullable = false)
	private Usuario usuario;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "tipo_de_contrato_id", nullable = false)
	private TipoDeContrato tipoDeContrato;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "propiedad_id", nullable = false)
	private Propiedad propiedad;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "estado_de_contrato_id", nullable = false)
	private EstadoDeContrato estadoDeContrato;

	@Column(name = "valor_estipulado", nullable = false, precision = 12, scale = 2)
	private BigDecimal valorEstipulado;

	@Column(name = "creado_en", nullable = false, updatable = false)
	private LocalDateTime creadoEn;

	@Column(name = "creado_por", nullable = false, updatable = false, length = 255)
	private String creadoPor;

	@Column(name = "actualizado_en", nullable = true)
	private LocalDateTime actualizadoEn;

	@Column(name = "actualizado_por", nullable = true, length = 255)
	private String actualizadoPor;

	public Long getId() { return id; }
	public void setId(Long id) { this.id = id; }

	public Usuario getUsuario() { return usuario; }
	public void setUsuario(Usuario usuario) {
		if (usuario == null) {
			throw new RuntimeException("El usuario no puede ser nulo");
		}
		this.usuario = usuario;
	}

	public TipoDeContrato getTipoDeContrato() { return tipoDeContrato; }
	public void setTipoDeContrato(TipoDeContrato tipoDeContrato) {
		if (tipoDeContrato == null) {
			throw new RuntimeException("El tipo de contrato no puede ser nulo");
		}
		this.tipoDeContrato = tipoDeContrato;
	}

	public Propiedad getPropiedad() { return propiedad; }
	public void setPropiedad(Propiedad propiedad) {
		if (propiedad == null) {
			throw new RuntimeException("La propiedad no puede ser nula");
		}
		this.propiedad = propiedad;
	}

	public EstadoDeContrato getEstadoDeContrato() { return estadoDeContrato; }
	public void setEstadoDeContrato(EstadoDeContrato estadoDeContrato) {
		if (estadoDeContrato == null) {
			throw new RuntimeException("El estado de contrato no puede ser nulo");
		}
		this.estadoDeContrato = estadoDeContrato;
	}

	public BigDecimal getValorEstipulado() { return valorEstipulado; }
	public void setValorEstipulado(BigDecimal valorEstipulado) {
		if (valorEstipulado == null || valorEstipulado.compareTo(BigDecimal.ZERO) < 0) {
			throw new RuntimeException("El valor estipulado no puede ser nulo ni menor a 0");
		}
		this.valorEstipulado = valorEstipulado;
	}

	public LocalDateTime getCreadoEn() { return creadoEn; }
	public void setCreadoEn(LocalDateTime creadoEn) { this.creadoEn = creadoEn; }

	public String getCreadoPor() { return creadoPor; }
	public void setCreadoPor(String creadoPor) {
		if (creadoPor == null || creadoPor.trim().isEmpty()) {
			throw new RuntimeException("El campo creadoPor no puede ser nulo o estar vacío");
		}
		this.creadoPor = creadoPor;
	}

	public LocalDateTime getActualizadoEn() { return actualizadoEn; }
	public void setActualizadoEn(LocalDateTime actualizadoEn) { this.actualizadoEn = actualizadoEn; }

	public String getActualizadoPor() { return actualizadoPor; }
	public void setActualizadoPor(String actualizadoPor) {
		if (actualizadoPor != null && actualizadoPor.trim().isEmpty()) {
			throw new RuntimeException("El campo actualizadoPor no puede estar vacío (puede ser nulo)");
		}
		this.actualizadoPor = actualizadoPor;
	}

	@PrePersist
	private void adquirido() {
		LocalDateTime ahora = LocalDateTime.now();
		if (creadoEn == null) creadoEn = ahora;
		if (actualizadoEn == null) actualizadoEn = ahora;
	}

	@PreUpdate
	private void modificacion() {
		actualizadoEn = LocalDateTime.now();
	}
}