package com.ufgGrupo6.sistemaDeBienesRaices.servicios;

import org.springframework.stereotype.Service;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.*;
import com.ufgGrupo6.sistemaDeBienesRaices.repositorios.*;
import jakarta.transaction.Transactional;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ServicioDeAlquiler {
    private final ServiciosDeUsuarios serviciosDeUsuarios;
    private final PropiedadRepositorio propiedadRepositorio;
    private final ContratoRepositorio contratoRepositorio;
    private final ContratoDeAlquilerRepositorio contratoDeAlquilerRepositorio;
    private final TipoDeContratoRepositorio tipoDeContratoRepositorio;
    private final EstadoDeContratoRepositorio estadoDeContratoRepositorio;
    private final EstadoDePropiedadRepositorio estadoDePropiedadRepositorio;
    private final CuotaRepositorio cuotaRepositorio;

    public ServicioDeAlquiler(
        ServiciosDeUsuarios serviciosDeUsuarios,
        PropiedadRepositorio propiedadRepositorio,
        ContratoRepositorio contratoRepositorio,
        ContratoDeAlquilerRepositorio contratoDeAlquilerRepositorio,
        TipoDeContratoRepositorio tipoDeContratoRepositorio,
        EstadoDeContratoRepositorio estadoDeContratoRepositorio,
        EstadoDePropiedadRepositorio estadoDePropiedadRepositorio,
        CuotaRepositorio cuotaRepositorio
    ) {
        this.serviciosDeUsuarios = serviciosDeUsuarios;
        this.propiedadRepositorio = propiedadRepositorio;
        this.contratoRepositorio = contratoRepositorio;
        this.contratoDeAlquilerRepositorio = contratoDeAlquilerRepositorio;
        this.tipoDeContratoRepositorio = tipoDeContratoRepositorio;
        this.estadoDeContratoRepositorio = estadoDeContratoRepositorio;
        this.estadoDePropiedadRepositorio = estadoDePropiedadRepositorio;
        this.cuotaRepositorio = cuotaRepositorio;
    }

    @Transactional
    public void alquiler(String email, Long propiedadId, Long cuotaId, LocalDateTime fechaInicioDeseada) {
        String emailAdmin = "admin@sv.admin.email.com";

        Usuario admin = serviciosDeUsuarios.buscarPorEmail(emailAdmin);
        if (admin == null) throw new RuntimeException("El usuario admin no existe en la BD.");

        Usuario usuarioAlquilador = serviciosDeUsuarios.obtenerOCrearUsuario(email, emailAdmin);

        Propiedad propiedad = propiedadRepositorio.findById(propiedadId)
            .orElseThrow(() -> new RuntimeException("Propiedad no encontrada"));

        if (propiedad.getTipoDePropiedad().getTipo().equalsIgnoreCase("TERRENO")) {
            throw new RuntimeException("Los terrenos no se pueden alquilar.");
        }

        if (!propiedad.getUsuario().getId().equals(admin.getId())) {
            throw new RuntimeException("La propiedad no pertenece al administrador.");
        }

        String estadoActual = propiedad.getEstadoDePropiedad().getEstado();
        if (!estadoActual.equalsIgnoreCase("DISPONIBLE") && !estadoActual.equalsIgnoreCase("ALQUILADA")) {
            throw new RuntimeException("La propiedad no está DISPONIBLE ni ALQUILADA, no se puede alquilar.");
        }

        LocalDateTime ahora = LocalDateTime.now().withSecond(0).withNano(0);
        if (fechaInicioDeseada == null || fechaInicioDeseada.isBefore(ahora) || fechaInicioDeseada.isEqual(ahora)) {
            throw new RuntimeException("La fecha de inicio debe ser en el futuro (minutos exactos).");
        }

        List<ContratoDeAlquiler> ultimosAlquileres = contratoDeAlquilerRepositorio.findUltimoAlquilerPorPropiedad(propiedadId);
        if (!ultimosAlquileres.isEmpty()) {
            ContratoDeAlquiler ultimo = ultimosAlquileres.get(0);
            if (fechaInicioDeseada.isBefore(ultimo.getFechaLimite())) {
                throw new RuntimeException("La propiedad ya está reservada hasta: " + ultimo.getFechaLimite());
            }
            long minutosDiferencia = Duration.between(ultimo.getFechaLimite(), fechaInicioDeseada).toMinutes();
            if (minutosDiferencia < 60) {
                throw new RuntimeException("Debe haber al menos 1 hora de diferencia entre reservas.");
            }
        }

        List<ContratoDeAlquiler> vencidos = contratoDeAlquilerRepositorio.findAlquileresVencidos(ahora);
        EstadoDeContrato estadoCompletado = estadoDeContratoRepositorio.findByEstado("COMPLETADO")
            .orElseThrow(() -> new RuntimeException("Estado 'COMPLETADO' no existe"));

        for (ContratoDeAlquiler vencido : vencidos) {
            vencido.getContrato().setEstadoDeContrato(estadoCompletado);
            vencido.getContrato().setActualizadoPor(emailAdmin);
            contratoRepositorio.save(vencido.getContrato());
        }

        Cuota cuota = cuotaRepositorio.findById(cuotaId)
            .orElseThrow(() -> new RuntimeException("La cuota no existe"));

        long diasAlquiler = extraerDiasDePeriodo(cuota.getPeriodo());
        LocalDateTime fechaFinAlquiler = fechaInicioDeseada.plusDays(diasAlquiler);

        TipoDeContrato tipo = tipoDeContratoRepositorio.findByTipo("ALQUILER")
            .orElseThrow(() -> new RuntimeException("Tipo de contrato 'ALQUILER' no existe"));

        EstadoDeContrato estadoEnProceso = estadoDeContratoRepositorio.findByEstado("EN PROCESO")
            .orElseThrow(() -> new RuntimeException("Estado 'EN PROCESO' no existe"));

        Contrato contrato = new Contrato();
        contrato.setUsuario(usuarioAlquilador);
        contrato.setPropiedad(propiedad);
        contrato.setTipoDeContrato(tipo);
        contrato.setEstadoDeContrato(estadoEnProceso);
        contrato.setValorEstipulado(propiedad.getValor());
        contrato.setCreadoPor(emailAdmin);
        contrato.setActualizadoPor(emailAdmin);
        contrato = contratoRepositorio.save(contrato);

        ContratoDeAlquiler contratoDeAlquiler = new ContratoDeAlquiler();
        contratoDeAlquiler.setContrato(contrato);
        contratoDeAlquiler.setCuota(cuota);
        contratoDeAlquiler.setFechaLimite(fechaFinAlquiler);
        contratoDeAlquiler.setCreadoPor(emailAdmin);
        contratoDeAlquiler.setActualizadoPor(emailAdmin);

        contratoDeAlquilerRepositorio.save(contratoDeAlquiler);

        if (estadoActual.equalsIgnoreCase("DISPONIBLE")) {
            EstadoDePropiedad estadoAlquilada = estadoDePropiedadRepositorio.findByEstado("ALQUILADA")
                .orElseThrow(() -> new RuntimeException("Estado 'ALQUILADA' no existe"));
            propiedad.setEstadoDePropiedad(estadoAlquilada);
            propiedad.setActualizadoPor(emailAdmin);
            propiedadRepositorio.save(propiedad);
        }
    }

    private long extraerDiasDePeriodo(String periodo) {
        if (periodo == null) throw new RuntimeException("El periodo no puede ser nulo");
        periodo = periodo.toUpperCase().trim();
        try {
            if (periodo.contains("SEMANA")) return Long.parseLong(periodo.replaceAll("\\D", "")) * 7;
            if (periodo.contains("MES")) return Long.parseLong(periodo.replaceAll("\\D", "")) * 30;
            if (periodo.contains("DIA")) return Long.parseLong(periodo.replaceAll("\\D", ""));
        } catch (NumberFormatException e) {
            throw new RuntimeException("Formato de periodo no válido: " + periodo);
        }
        throw new RuntimeException("No se pudo calcular la duración para el periodo: " + periodo);
    }
}