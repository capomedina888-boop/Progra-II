package com.ufgGrupo6.sistemaDeBienesRaices.repositorios;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.EstadoDePropiedad;

public interface EstadoDePropiedadRepositorio extends JpaRepository<EstadoDePropiedad, Long> {
    Optional<EstadoDePropiedad> findByEstado(String estado);
}