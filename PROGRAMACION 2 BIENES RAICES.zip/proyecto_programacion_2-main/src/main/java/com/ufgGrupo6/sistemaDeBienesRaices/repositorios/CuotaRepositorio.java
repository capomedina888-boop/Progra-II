package com.ufgGrupo6.sistemaDeBienesRaices.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.Cuota;

public interface CuotaRepositorio extends JpaRepository<Cuota, Long> {
}