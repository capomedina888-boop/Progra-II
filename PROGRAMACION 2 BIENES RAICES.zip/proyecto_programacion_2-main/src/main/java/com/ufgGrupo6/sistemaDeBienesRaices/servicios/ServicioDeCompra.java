package com.ufgGrupo6.sistemaDeBienesRaices.servicios;

import java.math.BigDecimal;
import org.springframework.stereotype.Service;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.*;
import com.ufgGrupo6.sistemaDeBienesRaices.repositorios.*;
import jakarta.transaction.Transactional;

@Service
public class ServicioDeCompra {
    private final ServiciosDeUsuarios serviciosDeUsuarios;
    private final PropiedadRepositorio propiedadRepositorio;
    private final ContratoRepositorio contratoRepositorio;
    private final TipoDeContratoRepositorio tipoDeContratoRepositorio;
    private final EstadoDeContratoRepositorio estadoDeContratoRepositorio;
    private final UbicacionRepositorio ubicacionRepositorio;
    private final TipoDePropiedadRepositorio tipoDePropiedadRepositorio;
    private final EstadoDePropiedadRepositorio estadoDePropiedadRepositorio;
    
    public ServicioDeCompra(
        ServiciosDeUsuarios serviciosDeUsuarios,
        PropiedadRepositorio propiedadRepositorio,
        ContratoRepositorio contratoRepositorio,
        TipoDeContratoRepositorio tipoDeContratoRepositorio,
        EstadoDeContratoRepositorio estadoDeContratoRepositorio,
        UbicacionRepositorio ubicacionRepositorio,
        TipoDePropiedadRepositorio tipoDePropiedadRepositorio,
        EstadoDePropiedadRepositorio estadoDePropiedadRepositorio
    ) {
        this.serviciosDeUsuarios = serviciosDeUsuarios;
        this.propiedadRepositorio = propiedadRepositorio;
        this.contratoRepositorio = contratoRepositorio;
        this.tipoDeContratoRepositorio = tipoDeContratoRepositorio;
        this.estadoDeContratoRepositorio = estadoDeContratoRepositorio;
        this.ubicacionRepositorio = ubicacionRepositorio;
        this.tipoDePropiedadRepositorio = tipoDePropiedadRepositorio;
        this.estadoDePropiedadRepositorio = estadoDePropiedadRepositorio;
    }
    
    @Transactional
    public void comprar(String email, BigDecimal valorPropiedad, String descripcionPropiedad, String tipoPropiedad, String departamento) {
        
        String emailAdmin = "admin@sv.admin.email.com";
        
        Usuario admin = serviciosDeUsuarios.buscarPorEmail(emailAdmin);
        if (admin == null) {
            throw new RuntimeException("El usuario administrador (" + emailAdmin + ") no existe en la base de datos. Debe crearlo primero.");
        }
        
        Usuario usuarioComprador = serviciosDeUsuarios.obtenerOCrearUsuario(email, emailAdmin);
        
        TipoDePropiedad tipoProp = tipoDePropiedadRepositorio.findByTipo(tipoPropiedad)
            .orElseThrow(() -> new RuntimeException("El tipo de propiedad no existe"));         
            
        Ubicacion ubicacion = ubicacionRepositorio.findByDepartamento(departamento)
            .orElseThrow(() -> new RuntimeException("La ubicación con departamento " + departamento + " no existe"));
            
        EstadoDePropiedad estadoProp = estadoDePropiedadRepositorio.findByEstado("DISPONIBLE")
            .orElseThrow(() -> new RuntimeException("Estado de propiedad no existe"));    
            
        Propiedad propiedad = new Propiedad();
        propiedad.setUsuario(admin);
        propiedad.setTipoDePropiedad(tipoProp);
        propiedad.setUbicacion(ubicacion);
        propiedad.setEstadoDePropiedad(estadoProp);
        propiedad.setValor(valorPropiedad);
        propiedad.setDescripcion(descripcionPropiedad);
        propiedad.setCreadoPor(emailAdmin);
        propiedad.setActualizadoPor(emailAdmin);
        propiedad = propiedadRepositorio.save(propiedad);
        
        TipoDeContrato tipo = tipoDeContratoRepositorio.findByTipo("COMPRA")
            .orElseThrow(() -> new RuntimeException("El tipo de contrato 'COMPRA' no existe en la BD"));
            
        EstadoDeContrato estado = estadoDeContratoRepositorio.findByEstado("ACTIVO")
            .orElseThrow(() -> new RuntimeException("El estado 'ACTIVO' no existe en la BD"));  
            
        Contrato contrato = new Contrato();
        contrato.setUsuario(usuarioComprador);
        contrato.setPropiedad(propiedad);
        contrato.setTipoDeContrato(tipo);
        contrato.setEstadoDeContrato(estado);
        contrato.setValorEstipulado(propiedad.getValor());
        contrato.setCreadoPor(emailAdmin);
        contrato.setActualizadoPor(emailAdmin);
        contratoRepositorio.save(contrato);
    }
}