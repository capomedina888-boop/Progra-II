package com.ufgGrupo6.sistemaDeBienesRaices.servicios;

import org.springframework.stereotype.Service;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.*;
import com.ufgGrupo6.sistemaDeBienesRaices.repositorios.*;
import jakarta.transaction.Transactional;

@Service
public class ServicioDeVenta {
    private final ServiciosDeUsuarios serviciosDeUsuarios;
    private final PropiedadRepositorio propiedadRepositorio;
    private final ContratoRepositorio contratoRepositorio;
    private final TipoDeContratoRepositorio tipoDeContratoRepositorio;
    private final EstadoDeContratoRepositorio estadoDeContratoRepositorio;
    private final EstadoDePropiedadRepositorio estadoDePropiedadRepositorio;

    public ServicioDeVenta(
        ServiciosDeUsuarios serviciosDeUsuarios,
        PropiedadRepositorio propiedadRepositorio,
        ContratoRepositorio contratoRepositorio,
        TipoDeContratoRepositorio tipoDeContratoRepositorio,
        EstadoDeContratoRepositorio estadoDeContratoRepositorio,
        EstadoDePropiedadRepositorio estadoDePropiedadRepositorio
    ) {
        this.serviciosDeUsuarios = serviciosDeUsuarios;
        this.propiedadRepositorio = propiedadRepositorio;
        this.contratoRepositorio = contratoRepositorio;
        this.tipoDeContratoRepositorio = tipoDeContratoRepositorio;
        this.estadoDeContratoRepositorio = estadoDeContratoRepositorio;
        this.estadoDePropiedadRepositorio = estadoDePropiedadRepositorio;
    }

    @Transactional
    public void vender(String email, Long propiedadId) {
        String emailAdmin = "admin@sv.admin.email.com";

        Usuario admin = serviciosDeUsuarios.buscarPorEmail(emailAdmin);
        if (admin == null) {
            throw new RuntimeException("El usuario administrador (" + emailAdmin + ") no existe en la base de datos.");
        }

        Usuario usuarioComprador = serviciosDeUsuarios.obtenerOCrearUsuario(email, emailAdmin);

        Propiedad propiedad = propiedadRepositorio.findById(propiedadId)
            .orElseThrow(() -> new RuntimeException("La propiedad con ID " + propiedadId + " no existe"));

        if (!propiedad.getUsuario().getId().equals(admin.getId())) {
            throw new RuntimeException("La propiedad no pertenece al administrador, no se puede vender directamente");
        }

        if (!propiedad.getEstadoDePropiedad().getEstado().equalsIgnoreCase("DISPONIBLE")) {
            throw new RuntimeException("La propiedad no está disponible para la venta");
        }

        usuarioComprador.agregarPropiedad(propiedad);

        TipoDeContrato tipo = tipoDeContratoRepositorio.findByTipo("VENTA")
            .orElseThrow(() -> new RuntimeException("El tipo de contrato 'VENTA' no existe en la BD"));

        EstadoDeContrato estado = estadoDeContratoRepositorio.findByEstado("ACTIVO")
            .orElseThrow(() -> new RuntimeException("El estado 'ACTIVO' no existe en la BD"));

        Contrato contrato = new Contrato();
        contrato.setUsuario(usuarioComprador);
        contrato.setPropiedad(propiedad);
        contrato.setTipoDeContrato(tipo);
        contrato.setEstadoDeContrato(estado);
        contrato.setValorEstipulado(propiedad.getValor());
        contrato.setCreadoPor(emailAdmin);
        contrato.setActualizadoPor(emailAdmin);

        contratoRepositorio.save(contrato);

        EstadoDePropiedad estadoVendida = estadoDePropiedadRepositorio.findByEstado("VENDIDA")
            .orElseThrow(() -> new RuntimeException("El estado 'VENDIDA' no existe en la BD"));
        propiedad.setEstadoDePropiedad(estadoVendida);
        propiedad.setActualizadoPor(emailAdmin);
        propiedadRepositorio.save(propiedad);
    }
}