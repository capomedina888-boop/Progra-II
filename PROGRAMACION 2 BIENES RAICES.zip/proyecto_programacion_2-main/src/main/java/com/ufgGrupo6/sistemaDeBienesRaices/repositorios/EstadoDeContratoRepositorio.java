package com.ufgGrupo6.sistemaDeBienesRaices.repositorios;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ufgGrupo6.sistemaDeBienesRaices.modelos.EstadoDeContrato;

public interface EstadoDeContratoRepositorio extends JpaRepository<EstadoDeContrato, Long> {
    Optional<EstadoDeContrato> findByEstado(String estado);
}